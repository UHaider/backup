# hello-obs
Hello world package for OBS
