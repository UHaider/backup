#include<stdio.h>

int main()
{
  printf("Saying Hello to OBS\n");
  return 0;
}
